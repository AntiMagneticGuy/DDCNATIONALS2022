import hashlib
from PIL import Image
import time
import sys

def delay_print(s, delay=0.05):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(delay)
    time.sleep(0.5)
    print()


def delay_print_ascii_art():
    # pass the image as command line argument
    img = Image.open("COOLSTORY.jpg")

    # resize the image
    width, height = img.size
    aspect_ratio = height/width
    new_width = 120
    new_height = aspect_ratio * new_width * 0.55
    img = img.resize((new_width, int(new_height)))
    # new size of image

    # convert image to greyscale format
    img = img.convert('L')

    pixels = img.getdata()

    # replace each pixel with a character from array
    chars = ["B","S","#","&","@","$","%","*",":",".", " "]
    new_pixels = [chars[pixel//25] for pixel in pixels]
    new_pixels = ''.join(new_pixels)

    # split string of chars into multiple strings of length equal to new width and create a list
    new_pixels_count = len(new_pixels)
    ascii_image = [new_pixels[index:index + new_width] for index in range(0, new_pixels_count, new_width)]
    ascii_image = "\n".join(ascii_image)
    delay_print(ascii_image, delay=0.01)

delay_print("Hello, welcome to my very cool story!")

# Ask the user for their name
name = input("What is your name? ")

hashed_name = hashlib.sha256(name.encode('utf-8')).hexdigest()

# If I'm playing, then I should just win right away
if hashed_name == "240b056da2b8f0cd466f06f0976874202ec2fab76ec5ade0f77c47065f8fa468":
    delay_print("You are the best player ever!")
    delay_print("You win!")
    delay_print_ascii_art()
    exit()

delay_print("Hello, " + name + "!")

# Ask the user for their age
age = input("How old are you? ")

# Ask the user for their hometown
hometown = input("Where do you live? ")

# Ask the user for what pronoun they prefer
pronoun = input("What are your pronouns (eg. she/he/they/...)? ")

delay_print("===== YOUR STORY STARTS HERE =====")

delay_print("Once upon a time, " + name + " was " + age + " years old.")
# TODO: Add a way to choose a pronoun
delay_print(f"{pronoun.capitalize()} lived in " + hometown + ".")

delay_print("One day, " + name + " was walking down the street when a homeless person came by.")
delay_print("The homeless person asked, \"Hey, can you help me?\"")
delay_print("\"Sure,\" " + name + " replied.")
delay_print("My dog is very hungry, but I don't have any food.")
delay_print("\"I can help you,\" " + name + " said.")

# Ask the player how they would like to find food for the dog
options = ["Walk down the street", "Go to the grocery store", "Go to the park", "Go to the library", "Go to the mall"]

delay_print("You are now on a mission to find food for the dog.")
delay_print("You can choose from the following options:")
for i, option in enumerate(options):
    delay_print(f"\t{i+1}) {option}")

delay_print("What would you like to do?")
choice = None
while choice is None:
    try:
        choice = int(input("Enter your choice: "))
        if choice < 1 or choice > len(options):
            delay_print("Invalid choice.")
            choice = None
    except ValueError:
        delay_print("Invalid choice.")

if choice == 1:
    delay_print("You chose to walk down the street.")
    delay_print("You fall down a dark alleyway and are eaten by a bear.")
    delay_print("GAME OVER")
    quit(0)
elif choice == 2:
    delay_print("You chose to go to the grocery store.")
    delay_print("You find a bag of food.")
    
elif choice == 3:
    delay_print("You chose to go to the park.")
    delay_print("Suddenly you hear a loud noise.")
    delay_print("You see a huge lion running towards you.")
    delay_print("You try to run away, but the lion is faster than you.")
    delay_print("You are eaten by the lion.")
    delay_print("GAME OVER")
    quit(0)

elif choice == 4:
    delay_print("You chose to go to the library.")
    delay_print("You found a book on how to take care of dogs.")
    delay_print("You read the book and learned how to take care of your dog.")
    delay_print("It was a great book!")
    delay_print("It says that you can buy dog food from a super market.")
    delay_print("You go to the supermarket and buy dog food.")
elif choice == 5:
    delay_print("You chose to go to the mall.")
    delay_print("You find a store called \"The Dog Store\".")
    delay_print("The store has a lot of dog food.")
    delay_print("You go to the store and buy dog food.")

else:
    quit(1)

delay_print("You return to the homeless person.")
delay_print("You give him the food.")
delay_print("The homeless perosn says, \"Thanks for the food!\"")

delay_print("You walk back to your home.")
delay_print("You go to your room.")
delay_print("A new picture is on the wall.")
delay_print("You look at the picture.")
delay_print("It looks like this:")
delay_print_ascii_art()