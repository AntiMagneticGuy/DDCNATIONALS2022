# My very own story game

This is a choose your own adventure game where a 
character is presented with a story and then
chooses a path to follow.

This is my first programming project, so please
be gentle with me.